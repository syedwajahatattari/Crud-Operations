import React from 'react'
import { FaBackward } from "react-icons/fa6";


const AddUser = () => {
  return (
    <div className='h-screen flex justify-center items-start'>
        <div className='w-[40vw] p-20'>
            <div className='bg-black text-white flex items-center rounded-lg w-24 gap-1 px-5 py-2 hover:scale-105 hover:cursor-pointer'>
                <FaBackward /> 
            <button className=''>Back</button>
            </div>
            <div className='flex flex-col mt-10 gap-5'>
              <h1 className='text-green-600 font-bold text-4xl text-center'>Add New User</h1>
              <form action="" className='flex flex-col gap-3'>
                <label htmlFor="fname">First Name: *</label>
                <input className='w-full p-2 rounded-md text-black border border-black rounded-md' type="text" id='fname' name='fname' required />
                <label htmlFor="lname">Last Name: *</label>
                <input className='w-full p-2 rounded-md text-black border border-black rounded-md' type="text" id='lname' name='lname' required />
                <label htmlFor="email">Email: *</label>
                <input className='w-full p-2 rounded-md text-black border border-black rounded-md' type="email" id='email' name='email' required />
                <label htmlFor="password">Password: *</label>
                <input className='w-full p-2 rounded-md text-black border border-black rounded-md' type="password" id='password' name='password' required />
                <button className='bg-purple-600 text-white font-bold p-3 rounded-md hover:scale-105 mt-5 uppercase' type='submit'>Add User</button>
              </form>
            </div>
        
        </div>
        
    </div>
  )
}

export default AddUser