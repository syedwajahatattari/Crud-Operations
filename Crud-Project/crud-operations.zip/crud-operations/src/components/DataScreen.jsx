import React from "react";
import { MdDelete } from "react-icons/md";
import { BiSolidEdit } from "react-icons/bi";


const DataScreen = () => {
  return (
    <div className="h-screen flex justify-center items-start">
      <div className="p-20 w-[80vw]">
        <button className="bg-black text-white flex items-center rounded-lg gap-1 px-5 py-2 hover:scale-105 hover:cursor-pointer">
          Add User
        </button>
        <div className="grid grid-cols-[10rem_1fr_1fr_1fr] border mt-10 rounded-lg text-center">
            <div className="border-r p-5 font-bold rounded-tl bg-blue-600 text-white">S No</div>
            <div className="border-r p-5 font-bold bg-blue-600 text-white">User Name</div>
            <div className="border-r p-5 font-bold bg-blue-600 text-white">User Email</div>
            <div className="p-5 font-bold rounded-tr bg-blue-600 text-white">Actions</div>
            <div className="border-r p-5">1</div>
            <div className="border-r p-5">Ali Raza</div>
            <div className="border-r p-5">ali@gmail.com</div>
            <div className="p-5 flex justify-center gap-3">
                <MdDelete className="hover:cursor-pointer hover:text-red-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-red-500 text-white transition rounded-md duration-700" size={25} />
                <BiSolidEdit className="hover:cursor-pointer hover:text-green-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-green-500 text-white transition rounded-md duration-700" size={25} />
            </div>    
            <div className="border-r border-t p-5">2</div>
            <div className="border-r border-t p-5">Ahmed Raza</div>
            <div className="border-r border-t p-5">ahmedraza@gmail.com</div>
            <div className="p-5 border-t flex justify-center gap-3">
                <MdDelete className="hover:cursor-pointer hover:text-red-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-red-500 text-white rounded-md transition duration-700" size={25} />
                <BiSolidEdit className="hover:cursor-pointer hover:text-green-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-green-500 text-white rounded-md transition duration-700" size={25} />
            </div>    
            <div className="border-r border-t p-5">3</div>
            <div className="border-r border-t p-5">Sohail Raza</div>
            <div className="border-r border-t p-5">sohailraza@gmail.com</div>
            <div className="p-5 border-t flex justify-center gap-3">
                <MdDelete className="hover:cursor-pointer hover:text-red-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-red-500 text-white rounded-md transition duration-700" size={25} />
                <BiSolidEdit className="hover:cursor-pointer hover:text-green-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-green-500 text-white rounded-md transition duration-700" size={25} />
            </div>    
            <div className="border-r border-t p-5">4</div>
            <div className="border-r border-t p-5">Zubair Butt</div>
            <div className="border-r  border-t p-5">zubairbutt@gmail.com</div>
            <div className="p-5 border-t flex justify-center gap-3">
                <MdDelete className="hover:cursor-pointer hover:text-red-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-red-500 text-white rounded-md transition duration-700" size={25} />
                <BiSolidEdit className="hover:cursor-pointer hover:text-green-600 hover:bg-white py-1 w-8 h-8 text-3xl bg-green-500 text-white rounded-md transition duration-700" size={25} />
            </div>    
        </div>
      </div>
    </div>
  );
};

export default DataScreen;
