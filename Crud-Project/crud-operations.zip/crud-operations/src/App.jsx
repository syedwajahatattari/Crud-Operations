import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import AddUser from './components/AddUser'
import UpdateUser from './components/UpdateUser'
import DataScreen from './components/DataScreen'

function App() {

  return (
    <>
      <AddUser />
      <UpdateUser />
      <DataScreen />
    </>
  )
}

export default App
